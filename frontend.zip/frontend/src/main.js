// importing named exports we use brackets
import {createElement,uploadImage } from './helpers.js';

// when importing 'default' exports, use below syntax
import API from './api.js';

const api  = new API();
var step = 0;
var status = 0;
// we can use this single api request multiple times
// const feed = api.getFeed();



// feed
// .then(posts => {
//     posts.reduce((parent, post) => {
        
//        parent.appendChild(createPostTile(post));
        
//        return parent;

//     }, document.getElementById('large-feed'))
// });



/**
 * Given a post, return a tile with the relevant data
 * @param   {object}        post 
 * @returns {HTMLElement}
 */
function createPostTile(post) {
    console.log(post);
    const section = createElement('section', null, { class: 'post' });
    var author = createElement('h2', post.meta.author, {id:'author',class: 'autor' });
    author.addEventListener('click',function(){
        api.getUserByName(post.meta.author).then(function(user){
            var feed = document.getElementById("large-feed");
            feed.innerHTML = "";
            feed.appendChild(createElement('p',user.usrname));
            feed.appendChild(createElement('p',user.email));
            feed.appendChild(createElement('p',"posts:"+user.posts.length));
            feed.appendChild(createElement('p',"following:"+user.following.length));
            var allPost = user.posts;
            for(var i= 0; i < allPost.length;i++){
                console.log(allPost[i]);
                api.getPost(allPost[i]).then(function(res){
                    console.log(res);
                    document.getElementById("large-feed").appendChild(createPostTile(res));
                })
            }
    
        });
    });
    section.appendChild(author);

    section.appendChild(createElement('img', null, 
        { src: 'data:image/png;base64,'+post.src, alt: post.meta.description_text, class: 'post-image' }));
        section.appendChild(createElement('p',post.meta.description_text,{class:'post-desc'}));
        var date = new Date(post.meta.published*1000);
        section.appendChild(createElement('p',date,{id:"id12"+post.id,class:'post-published'}));
        section.appendChild(createElement('p'),post.meta.comments,{class:'post-comment'});
        api.getThisUser().then(function(res){
            var userId = res.id;
            if(post.meta.likes.indexOf(userId) !=-1){
                var like = createElement('button',null,{id:"like"+post.id,class:"like",style:"height:50px;width:50px"});
                like.addEventListener('click',function(){
                    var img = document.getElementById("like"+post.id);
                    var classList = img.classList;

                    if(classList.contains('like')){
                        classList.remove('like');
                        classList.add('unlike');
                        var postId = post.id;   
                        api.unlike(postId);
                        console.log(like);
                    }else{
                        classList.remove('unlike');
                        classList.add('like');
                        var postId = post.id;   
                        api.like(postId);
                    }

                });
                document.getElementById("id12"+post.id).appendChild(like);
            }else{
                var like = createElement('button',null,{id:"like"+post.id,class:"unlike",style:"height:50px;width:50px"});
                like.addEventListener('click',function(){
                    var img = document.getElementById("like"+post.id);
                    var classList = img.classList;
                    if(classList.contains('like')){
                        classList.remove('like');
                        classList.add('unlike');
                        var postId = post.id;   
                        api.unlike(postId);

                    }else{
                        classList.remove('unlike');
                        classList.add('like');
                        var postId = post.id;   
                        api.like(postId);
                    }
                });
                document.getElementById("id12"+post.id).appendChild(like);
            }
        })

        //all show all likes button
        var likes = createElement('p',"likes:" + post.meta.likes.length,{class:'post-likes'});
        section.appendChild(likes);

 
        //show all likes     
        const table = createElement('table',null,{id:'likes',class:'likes',style:'display:none'});
        
        for(var i = 0;i <post.meta.likes.length;i++){
            api.getUserById(post.meta.likes[i]).then(function(user){
                table.appendChild(createElement('td',user.name));
            })
        }
        section.appendChild(table);
        




     





       //add show comments button


        //show all comments
        var button = createElement('p',"click to view all comments",{id:'show-comments',class:'show-comments'});
        section.appendChild(button);
        const commentsTable = createElement('table',null,{id:'commentsTable',class:'commentsTable',style:'display:none'});
        for(var i = 0;i <post.comments.length;i++){
            commentsTable.appendChild(createElement('tr',post.comments[i].author +":"+post.comments[i].comment));
        }
        section.appendChild(commentsTable);

        //write comments
        var commentArea = createElement('textarea',null,{id:"comment",style:"height:200px;width:300px"});
        commentArea.placeholder = "Enter your comments";
        section.appendChild(commentArea);
        var comment = createElement('button',"comment",{id:"comment"});
        comment.addEventListener('click',function(){
            var postId = post.id;
            var comment = document.getElementById("comment").value;
            api.comment(postId,comment).then(test=>{
                if(test.message == "success"){
                    alert("comment successfully");
                    var author = window.localStorage.getItem('userName');
                    commentsTable.appendChild(createElement('tr',author +":"+comment));
                }else if(test.message == "Comment cannot be empty"){
                    alert(test.message);
                };
            });
        });
        section.appendChild(comment);
        
        //add all listener
        likes.addEventListener('click',function(){
            var style = document.getElementById("likes").style.display;
            if(style == "none"){
                document.getElementById("likes").style.display = "";
            }else{
                document.getElementById("likes").style.display = "none";
            }});

        button.addEventListener('click',function(){
            var style = document.getElementById("commentsTable").style.display;
            if(style == "none"){
                document.getElementById("commentsTable").style.display = "";
            }else{
                document.getElementById("commentsTable").style.display = "none";
            }})

        
    return section;
}




function login(){
    var m = document.getElementById("id02");
    var usrname = m.value;
    var n = document.getElementById("id03");
    var psw = n.value;
    api.login(usrname,psw).then(function(post){
        if(post.message){
            alert(post.message);    
        }else{
            window.localStorage.setItem('AUTH_KEY', post.token);
            api.getThisUser().then(function(res){
                window.localStorage.setItem('userID',res.id);
                window.localStorage.setItem('userName',res.name);
                document.getElementById('id01').style.display='none';
                document.getElementById('post').style.display='';
                document.getElementById('login').style.display='none';
                document.getElementById('signup').style.display='none';
                document.getElementById('updateButton').style.display='block';
                showHomePage();
                profile();
                feed(step);
                search();
                console.log(window.localStorage.getItem('userID'))
                console.log(window.localStorage.getItem('userName'))
                status = 1;
            })

        }

    })
}


function signup(){
    var name = document.getElementById("id06").value;
    var usrname = document.getElementById("id07").value;
    var psw = document.getElementById("id08").value;
    var email = document.getElementById("id09").value;
    api.signup(usrname,psw,email,name).then(function(res){
        if(res.message){
            alert(res.message);
        }else{
            window.localStorage.setItem('AUTH_KEY', post.token);
            document.getElementById('id05').style.display='none';
        }
    })
}

function feed(n){

    if(status == 0) return;
    step = step +10; 
    api.getFeed(n).then(posts => {
        posts.posts.reduce((parent, post) => {
            parent.appendChild(createPostTile(post));
            return parent;
        }, document.getElementById('large-feed'))
    });
}

function post(){
    postToggle();
    var text = document.getElementById("post-text").value;
    var src = document.getElementById("post-image").src;
    var tmp = src.split(",");
    var image = tmp[1];
    api.post(text,image).then(function(res){
        console.log(res);
        if(res.post_id){
            alert("post Successfully -.-!");
        }
    });
}


function postToggle(){
    var style = document.getElementById("post-table").style.display;
    if(style == "none"){
         document.getElementById("post-table").style.display = "";
    }else{
        document.getElementById("post-table").style.display = "none";
    }
}



function profile(){
    var profileTable = createElement('section',null,{class:'profile'});
    //TODO:chan posts to image
    api.getThisUser().then(function(user){
        console.log(user);
        var main = document.getElementById('large-feed');
        var author = user.name;
        var posts = user.posts.length;
        var following = user.following.length;
        var followed = user.followed_num;
        main.appendChild(createElement('p', "PROFILE"));
        main.appendChild(createElement('p', author,{class: "profile-author"}));
        main.appendChild(createElement('p', "Posts: "+posts, {class: "profile-posts"}));
        main.appendChild(createElement('p', "Following: "+ following, {class: "profile-following"}));
        main.appendChild(createElement('p', "Followers: "+followed, {class: "profile-followed"}));   
    })
    

}

function search(){
    var input = createElement('input',null,{id:"serach",class:"search"});
    input.addEventListener('keydown',function(e){
        if(event.keyCode ==13){
            api.getUserByName(input.value).then(function(res){
                console.log(input.value);
                console.log(res);
                if(res.username == input.value){
                    otherHomePage(res.name);
                }else{
                    alert(res.message);
                }
            })
        }
    });

    input.placeholder="Who do you want search?";
    document.getElementById("id11").appendChild(input);

}



function homePage(){
    // console.log("asdfasd");
    api.getThisUser().then(function(user){
        var feed = document.getElementById("large-feed");
        feed.innerHTML = "";
        feed.appendChild(createElement('p',user.usrname));
        feed.appendChild(createElement('p',user.email));
        feed.appendChild(createElement('p',"posts:"+user.posts.length));
        feed.appendChild(createElement('p',"following:"+user.following.length));
        var allPost = user.posts;
        for(var i= 0; i < allPost.length;i++){
            console.log(allPost[i]);
            api.getPost(allPost[i]).then(function(res){
                console.log(res);
                document.getElementById("large-feed").appendChild(creatOwnPost(res));
            })
        }

    });
}
function otherHomePage(name){
    api.getUserByName(name).then(function(res){
        api.getThisUser().then(function(user){
            var feed = document.getElementById("large-feed");
            feed.innerHTML = "";
            var searchID = res.id;
            if(user.following.indexOf(searchID) != -1){
                console.log("BBBB");
                var follow = createElement('button',"unfollow",{class:"unfollow"});
                feed.appendChild(follow);
                follow.addEventListener('click',function(){
                    api.unfollow(name);
                    alert("unfollow successfully")
                })
                feed.appendChild(createElement('p',res.usrname));
                feed.appendChild(createElement('p',res.email));
                feed.appendChild(createElement('p',"posts:"+res.posts.length));
                feed.appendChild(createElement('p',"following:"+res.following.length));
                var allPost = res.posts;
                for(var i= 0; i < allPost.length;i++){
                    console.log(allPost[i]);
                    api.getPost(allPost[i]).then(function(posts){
                        console.log(posts);
                        document.getElementById("large-feed").appendChild(createPostTile(posts));
                    })
                }
            }else{
                console.log("AAAAAAA");
                var feed = document.getElementById("large-feed");
                feed.innerHTML = "";
                var unfollow = createElement('button',"follow",{class:"follow"});
                unfollow.addEventListener('click',function(){
                    api.follow(name);
                    alert("follow successfully")
                })  
                feed.appendChild(unfollow);
                feed.appendChild(createElement('p',res.usrname));
                feed.appendChild(createElement('p',res.email));
                feed.appendChild(createElement('p',"posts:"+res.posts.length));
                feed.appendChild(createElement('p',"following:"+res.following.length));
                var allPost = res.posts;
                for(var i= 0; i < allPost.length;i++){
                    console.log(allPost[i]);
                    api.getPost(allPost[i]).then(function(posts){
                        console.log(posts);
                        document.getElementById("large-feed").appendChild(createPostTile(posts));
                    })
                }
            }
        })


    });
        
}
function creatOwnPost(post){
    console.log(post);
    const section = createElement('section', null, { class: 'post' });
    var del = createElement('button',"delete",{type:"button",class:'delete'});
    del.addEventListener('click',function(){
        api.deletePost(post.id).then(function(res){
            if(res.message =="success"){
                alert("delete post successfully")
            }
        })
    });
    var update = createElement('p',"delete",{type:"button",class:'delete'});
    update
    section.appendChild(del);
    var author = createElement('h2', post.meta.author, {id:'author',class: 'autor' });
    author.addEventListener('click',function(){
        api.getUserByName(post.meta.author).then(function(user){
            var feed = document.getElementById("large-feed");
            feed.innerHTML = "";
            feed.appendChild(createElement('p',user.usrname));
            feed.appendChild(createElement('p',user.email));
            feed.appendChild(createElement('p',"posts:"+user.posts.length));
            feed.appendChild(createElement('p',"following:"+user.following.length));
            main.appendChild(createElement('p', "followers: "+followed, {class: "profile-followed"}));   
            var allPost = user.posts;
            for(var i= 0; i < allPost.length;i++){
                console.log(allPost[i]);
                api.getPost(allPost[i]).then(function(res){
                    console.log(res);
                    document.getElementById("large-feed").appendChild(createPostTile(res));
                })
            }   
    
        });
    });
    section.appendChild(author);

    section.appendChild(createElement('img', null, 
        { src: 'data:image/png;base64,'+post.src, alt: post.meta.description_text, class: 'post-image' }));
        section.appendChild(createElement('p',post.meta.description_text,{class:'post-desc'}));
        var date = new Date(post.meta.published*1000);
        section.appendChild(createElement('p',date,{id:"id12"+post.id,class:'post-published'}));
        section.appendChild(createElement('p'),post.meta.comments,{class:'post-comment'});
        api.getThisUser().then(function(res){
            var userId = res.id;
            if(post.meta.likes.indexOf(userId) !=-1){
                var like = createElement('button',null,{id:"like"+post.id,class:"like",style:"height:50px;width:50px"});
                like.addEventListener('click',function(){
                    var img = document.getElementById("like"+post.id);
                    var classList = img.classList;

                    if(classList.contains('like')){
                        console.log("asdfasdfasdfas");
                        classList.remove('like');
                        classList.add('unlike');
                        var postId = post.id;   
                        api.unlike(postId);
                        console.log(like);
                    }else{
                        classList.remove('unlike');
                        classList.add('like');
                        var postId = post.id;   
                        api.like(postId);
                    }

                });
                document.getElementById("id12"+post.id).appendChild(like);
            }else{
                var like = createElement('button',null,{id:"like"+post.id,class:"unlike",style:"height:50px;width:50px"});
                like.addEventListener('click',function(){
                    var img = document.getElementById("like"+post.id);
                    var classList = img.classList;
                    if(classList.contains('like')){
                        classList.remove('like');
                        classList.add('unlike');
                        var postId = post.id;   
                        api.unlike(postId);

                    }else{
                        classList.remove('unlike');
                        classList.add('like');
                        var postId = post.id;   
                        api.like(postId);
                    }
                });
                document.getElementById("id12"+post.id).appendChild(like);
            }
        })

        //all show all likes button
        var likes = createElement('p',"likes:" + post.meta.likes.length,{class:'post-likes'});
        section.appendChild(likes);

 
        //show all likes     
        const table = createElement('table',null,{id:'likes',class:'likes',style:'display:none'});
        
        for(var i = 0;i <post.meta.likes.length;i++){
            api.getUserById(post.meta.likes[i]).then(function(user){
                table.appendChild(createElement('td',user.name));
            })
        }
        section.appendChild(table);
        



       //add show comments button


        //show all comments
        var button = createElement('p',"click to view all comments",{id:'show-comments',class:'show-comments'});
        section.appendChild(button);
        const commentsTable = createElement('table',null,{id:'commentsTable',class:'commentsTable',style:'display:none'});
        for(var i = 0;i <post.comments.length;i++){
            commentsTable.appendChild(createElement('tr',post.comments[i].author +":"+post.comments[i].comment));
        }
        section.appendChild(commentsTable);

        //write comments
        var commentArea = createElement('textarea',null,{id:"comment",style:"height:200px;width:300px"});
        commentArea.placeholder = "Enter your comments";
        section.appendChild(commentArea);
        var comment = createElement('button',"comment",{id:"comment"});
        comment.addEventListener('click',function(){
            var postId = post.id;
            var comment = document.getElementById("comment").value;
            api.comment(postId,comment).then(test=>{
                if(test.message == "success"){
                    alert("comment successfully");
                    var author = window.localStorage.getItem('userName');
                    commentsTable.appendChild(createElement('tr',author +":"+comment));
                }else if(test.message == "Comment cannot be empty"){
                    alert(test.message);
                };
            });
        });
        section.appendChild(comment);
        
        //add all listener
        likes.addEventListener('click',function(){
            var style = document.getElementById("likes").style.display;
            if(style == "none"){
                document.getElementById("likes").style.display = "";
            }else{
                document.getElementById("likes").style.display = "none";
            }});

        button.addEventListener('click',function(){
            var style = document.getElementById("commentsTable").style.display;
            if(style == "none"){
                document.getElementById("commentsTable").style.display = "";
            }else{
                document.getElementById("commentsTable").style.display = "none";
            }})

        
    return section;



}

function showHomePage(){
    var button = createElement('button',"Homepage",{class:'homePage',id: 'homepage'});
    button.addEventListener('click',homePage);
    var main=document.getElementById('HomePage');
    main.appendChild(button);
}

function updateProfile(){
    var name = document.getElementById("updateName").value;
    var psw = document.getElementById("updatePassword").value;
    var email = document.getElementById("updateEmail").value;

    api.updataProfile(name,psw,email).then(function(res){
        if(res.msg == 'success'){
            alert("update successfully");
        }else{
            alert(res.msg);
        }
    })
}

function lowEnough(){
    var pageHeight = Math.max(document.body.scrollHeight,document.body.offsetHeight);
    var viewportHeight = window.innerHeight || document.documentElement.clientHeight||
    document.body.clientHeight||0;

    var scrollHeight = window.pageYOffset||document.body.scrollTop|| 0;

    return pageHeight - viewportHeight - scrollHeight < 20;
}


setInterval(() => {
    console.log(lowEnough());
    if(lowEnough()){
        feed(step);
        console.log("step:"+step);
    }
}, 1000);
document.getElementById("id10").addEventListener('click',signup);
document.getElementById("id04").addEventListener('click',login);
document.getElementById("post").addEventListener('click',postToggle);
document.getElementById("post-confirm").addEventListener('click',post);
document.getElementById('updateConfirm').addEventListener('click',updateProfile);

// Potential example to upload an image
const input = document.querySelector('input[type="file"]');

input.addEventListener('change', uploadImage);


