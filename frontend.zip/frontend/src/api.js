// change this when you integrate with the real API, or when u start using the dev server
const API_URL = 'http://localhost:5000'

const getJSON = (path, options) => 
    fetch(path, options)
        .then(res => res.json())
        .catch(err => console.warn(`API_ERROR: ${err.message}`));

/**
 * This is a sample class API which you may base your code on.
 * You don't have to do this as a class.
 */
export default class API {

    /**
     * Defaults to teh API URL
     * @param {string} url 
     */
    constructor(url = API_URL) {
        this.url = url;
    } 

    makeAPIRequest(path,obj) {
        return getJSON(`${this.url}/${path}`,obj);
    }


    /**
     * @returns auth'd user in json format
     */
    getMe() {
        return this.makeAPIRequest('me.json');
    }



    login(username,password){
        var obj = {
        "method":'POST',
        "headers": {
            "accept": "application/json",
            "Content-Type": "application/json"
        },
        "body" : JSON.stringify({
                "username": username,
                "password": password
            })
        }
        return this.makeAPIRequest("auth/login",obj);
    }

    signup(username,password,email,name){
        var obj = {
            "method":'POST',
            "headers":{
                "accept": "application/json",
                "Content-Type": "application/json"
            },
            "body" : JSON.stringify({
                "username": username,
                "password": password,
                "email": email,
                "name": name
            })
        }
        return this.makeAPIRequest("auth/signup",obj);
    }

    getFeed(p){
        var n = p + 10;
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');

        var obj = {
            "method":'GET',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            }
        }
        var url = "user/feed?p="+p+"&n="+n; 
        console.log(url);
        return this.makeAPIRequest(url,obj);
    }
    
    getUserById(id){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');
        var obj = {
            "method":'GET',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            }
        }
        var url = "user/?id="+id;
        return this.makeAPIRequest(url,obj);
    }

    getUserByName(username){

        var token = "Token " + window.localStorage.getItem('AUTH_KEY');
        var obj = {
            "method":'GET',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            }
        }
        var url = "user/?username="+username;
        return this.makeAPIRequest(url,obj);
    }

    getThisUser(){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');
        var obj = {
            "method":'GET',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            }
        }
        var url = "user/";
        return this.makeAPIRequest(url,obj);
    }



    like(postId){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');
        var obj = {
            "method":'PUT',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            }
        }
        var url = "post/like?id="+postId;
        return this.makeAPIRequest(url,obj);
    }


    unlike(postId){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');
        var obj = {
            "method":'PUT',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            }
        }
        var url = "post/unlike?id="+postId;
        return this.makeAPIRequest(url,obj);
    }

    post(desc,imgsrc){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');
        var obj = {
            "method":'POST',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            },
            "body" : JSON.stringify({
                "description_text": desc,
                "src": imgsrc
            })
            
        }
        var url = "post";
        return this.makeAPIRequest(url,obj);
    }

    comment(postId,comment){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');
        var obj = {
            "method":'PUT',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            },
            "body" :JSON.stringify({
                "comment": comment
            })
        }
        var url = "post/comment?id="+postId;
        return this.makeAPIRequest(url,obj);
    }

    getPost(postId){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');

        var obj = {
            "method":'GET',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            }
        }
        var url = "post/?id="+postId;
        return this.makeAPIRequest(url,obj);
    }


    follow(username){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');

        var obj = {
            "method":'PUT',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            }
        }
        var url = "user/follow?username="+username;
        return this.makeAPIRequest(url,obj);
    }

    unfollow(username){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');

        var obj = {
            "method":'PUT',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            }
        }
        var url = "user/unfollow?username="+username;
        return this.makeAPIRequest(url,obj);
    }

    deletePost(postId){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');

        var obj = {
            "method":'DELETE',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            }
        }

        var url = "post/?id="+postId;
        return this.makeAPIRequest(url,obj);

    }


    updatePost(desc,imgsrc){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');
        var obj = {
            "method":'POST',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            },
            "body" : JSON.stringify({
                "description_text": desc,
                "src": imgsrc
            })
            
        }
        var url = "post/?id="+postId;
        return this.makeAPIRequest(url,obj);
        
    }

    updataProfile(name,psw,email){
        var token = "Token " + window.localStorage.getItem('AUTH_KEY');
        var obj = {
            "method":'PUT',
            "headers":{
                "accept": "application/json",
                "Authorization": token,
                "Content-Type": "application/json"
            },
            "body" :JSON.stringify({
                "email": email,
                "name": name,
                "password": psw
            })
        }
        var url = "user/";
        return this.makeAPIRequest(url,obj);
    }
}
